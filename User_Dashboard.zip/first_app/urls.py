from django.urls import path
from . import views

urlpatterns = [
    path('', views.index),
    path('sign_in', views.sign_in),
    path('register', views.register),
    path('create_user', views.create_user),
    path('authenticate', views.authenticate),
    path('dashboard/admin', views.display_dashboard_admin),
    path('dashboard', views.display_dashboard),
    path('logout', views.logout),
    path('users/new', views.new),
    path('add_new_user', views.add_new_user),
    path('<int:user_id>/delete_user', views.delete_user),
    path('users/edit/<int:user_id>', views.display_user),
    path('users/update/<int:user_id>', views.update_user),
    path('users/change_password/<int:user_id>', views.change_password),
]